		</div>
	</div>
<footer class="col-md-12" style="background: rgb(42, 42, 42);padding: 20px;color: white;font-weight: bolder;text-shadow: 0px  0px 1px rgb(0, 0, 0);">
	<div class="container">
		<div class="col-sm-8">
			<div class="col-xs-7">

			</div>
		</div>
		<div class="col-sm-4 pull-right">Copyright © 2015</div>
	</div>
</footer>
</body>
</html>