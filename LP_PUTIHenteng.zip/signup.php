<html lang="en-US"><head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="1;url=https://www.del78.com/scripts/un981c6l?a_aid=f9604597&a_bid=bd085dfb&chan=livemovie7">
<title> Redirecting Sign Up </title>
</head>
<body>
<script>
var id_array = ["IDX" ];
window.onload = function(){
for(i=0; i < id_array.length; i++){
var tgt = document.getElementById(id_array[i]).href;
document.getElementById(id_array[i]).onclick = function(){
window.location.href= tgt;
return false;
};
</script>
<p align="middle"><img src="/pleasewait.gif" vspace="200">
</p>
</body>
</html>
<!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4325787,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?4325787&101" alt="free geoip" border="0"></a></noscript>
<!-- Histats.com  END  -->