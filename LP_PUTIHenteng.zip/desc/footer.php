		</div>
	</div>
<footer class="col-md-12" style="background: rgb(42, 42, 42);padding: 20px;color: white;font-weight: bolder;text-shadow: 0px  0px 1px rgb(0, 0, 0);">
	<div class="container">
		<div class="col-sm-8">

<a href="http://thetvdb.com" class="btn btn-primary" data-target="http://thetvdb.com" class="btn btn-primary pull-right" >Cari Foto TV</a>
<a href="http://www.tvmuse.com" class="btn btn-primary" data-target="http://www.tvmuse.com" class="btn btn-primary pull-right" >TV Muse</a>
<a href="http://www.sidereel.com" class="btn btn-primary" data-target="http://www.sidereel.com" class="btn btn-primary pull-right" >Sidereel</a>
<a href="http://www.airdates.tv" class="btn btn-primary" data-target="http://www.airdates.tv" class="btn btn-primary pull-right" >Air Dates</a>
<a href="http://next-episode.net" class="btn btn-primary" data-target="http://next-episode.net" class="btn btn-primary pull-right" >Next-Episode</a>
<a href="http://www.rottentomatoes.com" class="btn btn-primary" data-target="http://www.rottentomatoes.com" class="btn btn-primary pull-right" >Rottentomatoes</a>
<a href="https://trakt.tv" class="btn btn-primary" data-target="https://trakt.tv" class="btn btn-primary pull-right" >Trakt TV</a>
<a href="http://www.imdb.com" class="btn btn-primary" data-target="http://www.imdb.com" class="btn btn-primary pull-right" >IMDB</a>
<a href="http://www.boxofficemojo.com" class="btn btn-primary" data-target="http://www.boxofficemojo.com" class="btn btn-primary pull-right" >Box Office Mojo</a>
<a href="https://www.themoviedb.org/?language=en" class="btn btn-primary" data-target="https://www.themoviedb.org/?language=en" class="btn btn-primary pull-right" >TMDB</a>

		</div>

</footer>

</body>


</html>